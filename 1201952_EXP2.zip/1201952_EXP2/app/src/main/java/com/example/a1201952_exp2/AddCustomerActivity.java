package com.example.a1201952_exp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddCustomerActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_customer);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String[] options = { "Male", "Female" };
        final Spinner genderSpinner =(Spinner) findViewById(R.id.spinner_Gender);
        ArrayAdapter<String> objGenderArr = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, options);
        genderSpinner.setAdapter(objGenderArr);

        final EditText idEditText = (EditText)findViewById(R.id.editText_Id);
        final EditText nameEditText = (EditText)findViewById(R.id.editText_Name);
        final EditText phoneEditText = (EditText)findViewById(R.id.editText_Phone);

        // adding back button and showError textview
        TextView showErrorText = (TextView)findViewById(R.id.showError);
        Button back = (Button)findViewById(R.id.backButton);

        Button addCustomerButton = (Button) findViewById(R.id.button_Add_Customer);
        addCustomerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Customer newCustomer =new Customer();
                if(idEditText.getText().toString().isEmpty()) {
                    showErrorText.setText("Error: Please Enter ID");
                    return;
                }
                else newCustomer.setmCustomerId(Long.parseLong(idEditText.getText().toString()));

                if(nameEditText.getText().toString().isEmpty()) {
                    showErrorText.setText("Error: Please Enter Name");
                    return;
                }

                else newCustomer.setmName(nameEditText.getText().toString());

                if(phoneEditText.getText().toString().isEmpty()) {
                    showErrorText.setText("Error: Please Enter Phone");
                    return;
                }
                else newCustomer.setmPhone(phoneEditText.getText().toString());

                newCustomer.setmGender(genderSpinner.getSelectedItem().toString());

                // add the customer to the database
                DataBaseHelper dataBaseHelper =new DataBaseHelper(AddCustomerActivity.this,"DB_NAME_EXP4",null,1);
                dataBaseHelper.insertCustomer(newCustomer);

                Intent intent=new Intent(AddCustomerActivity.this,MainActivity.class);
                AddCustomerActivity.this.startActivity(intent);
                finish();
            }
        });


        // back button event listener
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(AddCustomerActivity.this,MainActivity.class);
                AddCustomerActivity.this.startActivity(intent);
                finish();
            }
        });





    }
}